//
//  RootView.swift
//  Group_4
//
//  Created by Aathi Abhishek T on 2024-06-20.
//
import Foundation
// represent possible roots of the navigation flow using enum cases
enum RootView{
    case Login
    case Home
    case SignUp
   // case NewWalk
}
